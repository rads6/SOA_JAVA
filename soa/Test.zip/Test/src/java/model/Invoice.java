/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;

/**
 *
 * @author Suvarna
 */
public class Invoice {
    
int ExpenseID;
    
    int EmployeeID;
  
    String ExpenseType;
    int InvoicesId;
    int PriceID;
    String locationIDFrom;
    String locationIDTO;
      
    String locationNameFrom;
    String locationNameTo;
    int price;
    String PO;
    Date OrderDate;
    int OrderID;
    int customerID;
    int BillingAddress;
    String ContactName;
    int CellNumber;
    int transactionID;
    int locationID;
    String locationCode;

    public int getExpenseID() {
        return ExpenseID;
    }

    public void setExpenseID(int ExpenseID) {
        this.ExpenseID = ExpenseID;
    }

    public int getEmployeeID() {
        return EmployeeID;
    }

    public void setEmployeeID(int EmployeeID) {
        this.EmployeeID = EmployeeID;
    }

    public String getExpenseType() {
        return ExpenseType;
    }

    public void setExpenseType(String ExpenseType) {
        this.ExpenseType = ExpenseType;
    }

    public int getInvoicesId() {
        return InvoicesId;
    }

    public void setInvoicesId(int InvoicesId) {
        this.InvoicesId = InvoicesId;
    }

    public int getPriceID() {
        return PriceID;
    }

    public void setPriceID(int PriceID) {
        this.PriceID = PriceID;
    }

    public String getLocationIDFrom() {
        return locationIDFrom;
    }

    public void setLocationIDFrom(String locationIDFrom) {
        this.locationIDFrom = locationIDFrom;
    }

    public String getLocationIDTO() {
        return locationIDTO;
    }

    public void setLocationIDTO(String locationIDTO) {
        this.locationIDTO = locationIDTO;
    }

    public String getLocationNameFrom() {
        return locationNameFrom;
    }

    public void setLocationNameFrom(String locationNameFrom) {
        this.locationNameFrom = locationNameFrom;
    }

    public String getLocationNameTo() {
        return locationNameTo;
    }

    public void setLocationNameTo(String locationNameTo) {
        this.locationNameTo = locationNameTo;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getPO() {
        return PO;
    }

    public void setPO(String PO) {
        this.PO = PO;
    }

    public Date getOrderDate() {
        return OrderDate;
    }

    public void setOrderDate(Date OrderDate) {
        this.OrderDate = OrderDate;
    }

    public int getOrderID() {
        return OrderID;
    }

    public void setOrderID(int OrderID) {
        this.OrderID = OrderID;
    }

    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public int getBillingAddress() {
        return BillingAddress;
    }

    public void setBillingAddress(int BillingAddress) {
        this.BillingAddress = BillingAddress;
    }

    public String getContactName() {
        return ContactName;
    }

    public void setContactName(String ContactName) {
        this.ContactName = ContactName;
    }

    public int getCellNumber() {
        return CellNumber;
    }

    public void setCellNumber(int CellNumber) {
        this.CellNumber = CellNumber;
    }

    public int getTransactionID() {
        return transactionID;
    }

    public void setTransactionID(int transactionID) {
        this.transactionID = transactionID;
    }

    public int getLocationID() {
        return locationID;
    }

    public void setLocationID(int locationID) {
        this.locationID = locationID;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }

    public int getPostalcode() {
        return postalcode;
    }

    public void setPostalcode(int postalcode) {
        this.postalcode = postalcode;
    }
    
    
  
    int postalcode;
}
