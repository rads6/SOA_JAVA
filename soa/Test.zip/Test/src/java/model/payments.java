/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Date;

/**
 *
 * @author Suvarna
 */
public class payments {
    int PaymentID;
    int OrderID;
    String PaymentMethodID;
    int PaymentAmount;
    Date PaymentDate;
    int CheckNumber;
    String CreditCard;
    String CreditCardNumber;
    String CardholdersName;
    Date CreditCardExpDate;
    int CreditCardAuthorizationNumber;

    public int getPaymentID() {
        return PaymentID;
    }

    public void setPaymentID(int PaymentID) {
        this.PaymentID = PaymentID;
    }

    public int getOrderID() {
        return OrderID;
    }

    public void setOrderID(int OrderID) {
        this.OrderID = OrderID;
    }

    public String getPaymentMethodID() {
        return PaymentMethodID;
    }

    public void setPaymentMethodID(String PaymentMethodID) {
        this.PaymentMethodID = PaymentMethodID;
    }

    public int getPaymentAmount() {
        return PaymentAmount;
    }

    public void setPaymentAmount(int PaymentAmount) {
        this.PaymentAmount = PaymentAmount;
    }

    public Date getPaymentDate() {
        return PaymentDate;
    }

    public void setPaymentDate(Date PaymentDate) {
        this.PaymentDate = PaymentDate;
    }

    public int getCheckNumber() {
        return CheckNumber;
    }

    public void setCheckNumber(int CheckNumber) {
        this.CheckNumber = CheckNumber;
    }

    public String getCreditCard() {
        return CreditCard;
    }

    public void setCreditCard(String CreditCard) {
        this.CreditCard = CreditCard;
    }

    public String getCreditCardNumber() {
        return CreditCardNumber;
    }

    public void setCreditCardNumber(String CreditCardNumber) {
        this.CreditCardNumber = CreditCardNumber;
    }

    public String getCardholdersName() {
        return CardholdersName;
    }

    public void setCardholdersName(String CardholdersName) {
        this.CardholdersName = CardholdersName;
    }

    public Date getCreditCardExpDate() {
        return CreditCardExpDate;
    }

    public void setCreditCardExpDate(Date CreditCardExpDate) {
        this.CreditCardExpDate = CreditCardExpDate;
    }

    public int getCreditCardAuthorizationNumber() {
        return CreditCardAuthorizationNumber;
    }

    public void setCreditCardAuthorizationNumber(int CreditCardAuthorizationNumber) {
        this.CreditCardAuthorizationNumber = CreditCardAuthorizationNumber;
    }
    
    
    
   
}
