/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Suvarna
 */
public class Expenses {
    int EmployeeID;
    String ExpenseType;
    String PurposeofExpense;
    int AmountSpent;
    String Description;
    int DatePurchased ;
    int DateSubmitted;
    int AdvanceAmount;
    String PaymentMethod;

    public int getEmployeeID() {
        return EmployeeID;
    }

    public void setEmployeeID(int EmployeeID) {
        this.EmployeeID = EmployeeID;
    }

    public String getExpenseType() {
        return ExpenseType;
    }

    public void setExpenseType(String ExpenseType) {
        this.ExpenseType = ExpenseType;
    }

    public String getPurposeofExpense() {
        return PurposeofExpense;
    }

    public void setPurposeofExpense(String PurposeofExpense) {
        this.PurposeofExpense = PurposeofExpense;
    }

    public int getAmountSpent() {
        return AmountSpent;
    }

    public void setAmountSpent(int AmountSpent) {
        this.AmountSpent = AmountSpent;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public int getDatePurchased() {
        return DatePurchased;
    }

    public void setDatePurchased(int DatePurchased) {
        this.DatePurchased = DatePurchased;
    }

    public int getDateSubmitted() {
        return DateSubmitted;
    }

    public void setDateSubmitted(int DateSubmitted) {
        this.DateSubmitted = DateSubmitted;
    }

    public int getAdvanceAmount() {
        return AdvanceAmount;
    }

    public void setAdvanceAmount(int AdvanceAmount) {
        this.AdvanceAmount = AdvanceAmount;
    }

    public String getPaymentMethod() {
        return PaymentMethod;
    }

    public void setPaymentMethod(String PaymentMethod) {
        this.PaymentMethod = PaymentMethod;
    }
    
    
    
}
