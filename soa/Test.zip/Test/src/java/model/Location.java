/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Suvarna
 */
public class Location {
    int locationID;
    String locName;
    String locationCode;
    String isActive;
    int customerID;
    String Address;
    String Chicago;
    String Illinois;
     int postalCode;
     String locationContactName;
     int locPhone;
     String locEmail;

    public int getLocationID() {
        return locationID;
    }

    public void setLocationID(int locationID) {
        this.locationID = locationID;
    }

    public String getLocName() {
        return locName;
    }

    public void setLocName(String locName) {
        this.locName = locName;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String Address) {
        this.Address = Address;
    }

    public String getChicago() {
        return Chicago;
    }

    public void setChicago(String Chicago) {
        this.Chicago = Chicago;
    }

    public String getIllinois() {
        return Illinois;
    }

    public void setIllinois(String Illinois) {
        this.Illinois = Illinois;
    }

    public int getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(int postalCode) {
        this.postalCode = postalCode;
    }

    public String getLocationContactName() {
        return locationContactName;
    }

    public void setLocationContactName(String locationContactName) {
        this.locationContactName = locationContactName;
    }

    public int getLocPhone() {
        return locPhone;
    }

    public void setLocPhone(int locPhone) {
        this.locPhone = locPhone;
    }

    public String getLocEmail() {
        return locEmail;
    }

    public void setLocEmail(String locEmail) {
        this.locEmail = locEmail;
    }
     
     
     
    
}
