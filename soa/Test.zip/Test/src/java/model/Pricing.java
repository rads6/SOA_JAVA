/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Suvarna
 */
public class Pricing {
    int priceID;
    String locationIDFrom;
    String locationIDTO;
   
    int price;
    
    String locationNameFrom;
    String locationNameTo;
  
    int customerID;

    public int getPriceID() {
        return priceID;
    }

    public void setPriceID(int priceID) {
        this.priceID = priceID;
    }

    public String getLocationIDFrom() {
        return locationIDFrom;
    }

    public void setLocationIDFrom(String locationIDFrom) {
        this.locationIDFrom = locationIDFrom;
    }

    public String getLocationIDTO() {
        return locationIDTO;
    }

    public void setLocationIDTO(String locationIDTO) {
        this.locationIDTO = locationIDTO;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public String getLocationNameFrom() {
        return locationNameFrom;
    }

    public void setLocationNameFrom(String locationNameFrom) {
        this.locationNameFrom = locationNameFrom;
    }

    public String getLocationNameTo() {
        return locationNameTo;
    }

    public void setLocationNameTo(String locationNameTo) {
        this.locationNameTo = locationNameTo;
    }

    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }
}
