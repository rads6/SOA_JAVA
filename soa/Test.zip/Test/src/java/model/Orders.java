/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Date;

/**
 *
 * @author Suvarna
 */
public class Orders {
    
    int OrderID;
  Date OrderDate;
       int CustomerID;
    int EmployeeID;
    int TruckID;
    String isSPecial;
    int PurchaseOrderNumber;
    int OrderTotalAmount;
    int VIN;

    public int getOrderID() {
        return OrderID;
    }

    public void setOrderID(int OrderID) {
        this.OrderID = OrderID;
    }

    public Date getOrderDate() {
        return OrderDate;
    }

    public void setOrderDate(Date OrderDate) {
        this.OrderDate = OrderDate;
    }

    public int getCustomerID() {
        return CustomerID;
    }

    public void setCustomerID(int CustomerID) {
        this.CustomerID = CustomerID;
    }

    public int getEmployeeID() {
        return EmployeeID;
    }

    public void setEmployeeID(int EmployeeID) {
        this.EmployeeID = EmployeeID;
    }

    public int getTruckID() {
        return TruckID;
    }

    public void setTruckID(int TruckID) {
        this.TruckID = TruckID;
    }

    public String getIsSPecial() {
        return isSPecial;
    }

    public void setIsSPecial(String isSPecial) {
        this.isSPecial = isSPecial;
    }

    public int getPurchaseOrderNumber() {
        return PurchaseOrderNumber;
    }

    public void setPurchaseOrderNumber(int PurchaseOrderNumber) {
        this.PurchaseOrderNumber = PurchaseOrderNumber;
    }

    public int getOrderTotalAmount() {
        return OrderTotalAmount;
    }

    public void setOrderTotalAmount(int OrderTotalAmount) {
        this.OrderTotalAmount = OrderTotalAmount;
    }

    public int getVIN() {
        return VIN;
    }

    public void setVIN(int VIN) {
        this.VIN = VIN;
    }
  
    
}
