package parser;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

//import Trucking_Java_Object.comments;

import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;

public class DomParserOrders {

  public static void main(String argv[]) {
	  
	//comments comments = new comments();
    try {

	File fXmlFile = new File("C:/Users/gupta/workspace/WebService/XML/orders.xml");
	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	Document doc = dBuilder.parse(fXmlFile);

	
	doc.getDocumentElement().normalize();

	System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

	NodeList nList = doc.getElementsByTagName("record");

	System.out.println("----------------------------");

	for (int temp = 0; temp < nList.getLength(); temp++) {

		Node nNode = nList.item(temp);

		System.out.println("\nCurrent Element :" + nNode.getNodeName());

		if (nNode.getNodeType() == Node.ELEMENT_NODE) {

			Element eElement = (Element) nNode;
			

			
			System.out.println("OrderID : " + eElement.getElementsByTagName("OrderID").item(0).getTextContent());
			System.out.println("OrderDate : " + eElement.getElementsByTagName("OrderDate").item(0).getTextContent());
			System.out.println("CustomerID : " + eElement.getElementsByTagName("CustomerID").item(0).getTextContent());
			System.out.println("EmployeeID : " + eElement.getElementsByTagName("EmployeeID").item(0).getTextContent());
			System.out.println("TruckID : " + eElement.getElementsByTagName("TruckID").item(0).getTextContent());
			System.out.println("isSPecial : " + eElement.getElementsByTagName("isSPecial").item(0).getTextContent());
			System.out.println("PurchaseOrderNumber : " + eElement.getElementsByTagName("PurchaseOrderNumber").item(0).getTextContent());
			System.out.println("OrderTotalAmount : " + eElement.getElementsByTagName("OrderTotalAmount").item(0).getTextContent());
			System.out.println("VIN : " + eElement.getElementsByTagName("VIN").item(0).getTextContent());
			
			
		}
	}
    } catch (Exception e) {
	e.printStackTrace();
    }
  }

}