package parser;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SaxParserPayments {

   public static void main(String argv[]) {

    try {

	SAXParserFactory factory = SAXParserFactory.newInstance();
	SAXParser saxParser = factory.newSAXParser();

	DefaultHandler handler = new DefaultHandler() {
        boolean PaymentID = false;
	boolean OrderID = false;
	boolean PaymentMethodID = false;
	boolean PaymentAmount = false;
	boolean PaymentDate = false;
	boolean CheckNumber = false;
	boolean CreditCard = false;
	boolean CreditCardNumber = false;
	boolean CardholdersName = false;
        boolean CreditCardExpDate = false;
	boolean CreditCardAuthorizationNumber = false;
	

	public void startElement(String uri, String localName,String qName,
                Attributes attributes) throws SAXException {

		System.out.println("Start Element :" + qName);

		if (qName.equalsIgnoreCase("PaymentID")) {
			PaymentID = true;
		}

		if (qName.equalsIgnoreCase("OrderID")) {
			OrderID = true;
		}

		if (qName.equalsIgnoreCase("PaymentMethodID")) {
			PaymentMethodID = true;
		}

		if (qName.equalsIgnoreCase("PaymentAmount")) {
			PaymentAmount = true;
		}
		if (qName.equalsIgnoreCase("PaymentDate")) {
			PaymentDate = true;
		}
                if (qName.equalsIgnoreCase("CheckNumber")) {
			CheckNumber = true;
		}

		if (qName.equalsIgnoreCase("CreditCard")) {
			CreditCard = true;
		}

		if (qName.equalsIgnoreCase("CreditCardNumber")) {
			CreditCardNumber = true;
		}
		if (qName.equalsIgnoreCase("CardholdersName")) {
			CardholdersName = true;
		} 
               
		if (qName.equalsIgnoreCase("CreditCardExpDate")) {
			CreditCardExpDate = true;
		}

		if (qName.equalsIgnoreCase("CreditCardAuthorizationNumber")) {
			CreditCardAuthorizationNumber = true;
		}
		
		
	}

	public void endElement(String uri, String localName,
		String qName) throws SAXException {

		System.out.println("End Element :" + qName);

	}

	public void characters(char ch[], int start, int length) throws SAXException {

		if (PaymentID) {
			System.out.println("PaymentID : " + new String(ch, start, length));
			PaymentID = false;
		}

		if (OrderID) {
			System.out.println("OrderID : " + new String(ch, start, length));
			OrderID = false;
		}

		if (PaymentMethodID) {
			System.out.println("PaymentMethodID : " + new String(ch, start, length));
			PaymentMethodID = false;
		}

		if (PaymentAmount) {
			System.out.println("PaymentAmount : " + new String(ch, start, length));
			PaymentAmount = false;
		}
		if (PaymentDate) {
			System.out.println("PaymentDate : " + new String(ch, start, length));
			PaymentDate = false;
		}
               if (CheckNumber) {
			System.out.println("CheckNumber : " + new String(ch, start, length));
			CheckNumber = false;
		}

		if (CreditCard) {
			System.out.println("CreditCard : " + new String(ch, start, length));
			CreditCard = false;
		}

		if (CreditCardNumber) {
			System.out.println("CreditCardNumber : " + new String(ch, start, length));
			CreditCardNumber = false;
		}
		if (CardholdersName) {
			System.out.println("CardholdersName : " + new String(ch, start, length));
			CardholdersName = false;
		}
                if (CreditCardExpDate) {
			System.out.println("CreditCardExpDate : " + new String(ch, start, length));
			CreditCardExpDate = false;
		}

		if (CreditCardAuthorizationNumber) {
			System.out.println("CreditCardAuthorizationNumber : " + new String(ch, start, length));
			CreditCardAuthorizationNumber = false;
		}
		
		
	}

     };

       saxParser.parse("C:/Users/gupta/workspace/WebService/XML/Payments.xml", handler);

     } catch (Exception e) {
       e.printStackTrace();
     }

   }

}