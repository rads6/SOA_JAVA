/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import model.*;

//import Trucking_Java_Object.Locations;

import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.DOMException;
import org.xml.sax.SAXException;
/**
 *
 * @author Suvarna
 */
public class DomParserLocations {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Location loc = new Location();
         try {

	File fXmlFile = new File("..\\SOA_Project1\\src\\XML\\Location.xml");
	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	Document doc = dBuilder.parse(fXmlFile);
	doc.getDocumentElement().normalize();

	System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

	NodeList nList = doc.getElementsByTagName("record");

	/*System.out.println("----------------------------");*/

	for (int temp = 0; temp < nList.getLength(); temp++) {

		Node nNode = nList.item(temp);

		System.out.println("\nCurrent Element :" + nNode.getNodeName());

		if (nNode.getNodeType() == Node.ELEMENT_NODE) {

			Element eElement = (Element) nNode;
                        
//			loc.setLocationID(Integer.parseInt(eElement.getElementsByTagName("locationID").item(0).getTextContent()));
//			loc.setLocName(eElement.getElementsByTagName("locName").item(0).getTextContent());
//                        loc.setLocationCode(eElement.getElementsByTagName("locationCode").item(0).getTextContent());
//                        loc.setIsActive(eElement.getElementsByTagName("isActive").item(0).getTextContent());
//                        loc.setCustomerID(Integer.parseInt(eElement.getElementsByTagName("customerID").item(0).getTextContent()));
//                        loc.setAddress(eElement.getElementsByTagName("Address").item(0).getTextContent());
//                        loc.setCity(eElement.getElementsByTagName("city").item(0).getTextContent());
//                        loc.setState(eElement.getElementsByTagName("state").item(0).getTextContent());
//                        loc.setPostalcode(Integer.parseInt(eElement.getElementsByTagName("postalCode").item(0).getTextContent()));
//                        loc.setLocationcontactname(eElement.getElementsByTagName("locationContactName").item(0).getTextContent());
//                       loc.setLocphone(Integer.parseInt(eElement.getElementsByTagName("locationContactName").item(0).getTextContent()));
//                       loc.setEmailID(eElement.getElementsByTagName("locEmail").item(0).getTextContent());
//                      
                        System.out.println("locationID : " + eElement.getElementsByTagName("locationID").item(0).getTextContent());
			System.out.println("locName : " + eElement.getElementsByTagName("locName").item(0).getTextContent());
			System.out.println("locationCode : " + eElement.getElementsByTagName("locationCode").item(0).getTextContent());
			System.out.println("isActive : " + eElement.getElementsByTagName("isActive").item(0).getTextContent());
			System.out.println("customerID : " + eElement.getElementsByTagName("customerID").item(0).getTextContent());
                        System.out.println("Address : " + eElement.getElementsByTagName("Address").item(0).getTextContent());
                        System.out.println("city : " + eElement.getElementsByTagName("city").item(0).getTextContent());
                        System.out.println("state : " + eElement.getElementsByTagName("state").item(0).getTextContent());
                        System.out.println("postalCode : " + eElement.getElementsByTagName("postalCode").item(0).getTextContent());
                        System.out.println("locationContactName : " + eElement.getElementsByTagName("locationContactName").item(0).getTextContent());
                        System.out.println("locPhone : " + eElement.getElementsByTagName("locPhone").item(0).getTextContent());
                        System.out.println("locEmail : " + eElement.getElementsByTagName("locEmail").item(0).getTextContent());
			

		}
	}
    } catch (IOException | NumberFormatException | ParserConfigurationException | DOMException | SAXException e) {
    }
    }
    
}
