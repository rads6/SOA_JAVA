package parser;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import model.*;

import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;

public class DomParserTrucks {

  public static void main(String argv[]) {
	Trucks truck = new Trucks();
    try {

	File fXmlFile = new File("..\\SOA_Project1\\src\\XML\\Trucks.xml");
	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	Document doc = dBuilder.parse(fXmlFile);
	doc.getDocumentElement().normalize();

	System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

	NodeList nList = doc.getElementsByTagName("record");

	System.out.println("----------------------------");

	for (int temp = 0; temp < nList.getLength(); temp++) {

		Node nNode = nList.item(temp);

		System.out.println("\nCurrent Element :" + nNode.getNodeName());

		if (nNode.getNodeType() == Node.ELEMENT_NODE) {

			Element eElement = (Element) nNode;
			truck.setTruckNo(Integer.parseInt(eElement.getElementsByTagName("TruckNo").item(0).getTextContent()));
			truck.setMake(eElement.getElementsByTagName("Make").item(0).getTextContent());
			truck.setYear(Integer.parseInt(eElement.getElementsByTagName("Year").item(0).getTextContent()));
			truck.setModel(Integer.parseInt(eElement.getElementsByTagName("Model").item(0).getTextContent()));
			truck.setLicensePlateNo(eElement.getElementsByTagName("LicensePlateNo").item(0).getTextContent());
			truck.setEmployeeId(Integer.parseInt(eElement.getElementsByTagName("EmployeeID").item(0).getTextContent()));
			truck.setColor(eElement.getElementsByTagName("Color").item(0).getTextContent());
			truck.setVin(Integer.parseInt(eElement.getElementsByTagName("VIN").item(0).getTextContent()));
			

		}
	}
    } catch (Exception e) {
	e.printStackTrace();
    }
  }

}