package parser;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;

public class DomParserInvoice {

  public static void main(String argv[]) {

    try {

	File fXmlFile = new File("E:\\Study\\Sem1\\510_JP\\Workspace\\WebService\\src\\parser\\Invoice.xml");
	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	Document doc = dBuilder.parse(fXmlFile);

	doc.getDocumentElement().normalize();

	System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

	NodeList nList = doc.getElementsByTagName("InvoicesData");

	System.out.println("----------------------------");

	for (int temp = 0; temp < nList.getLength(); temp++) {

		Node nNode = nList.item(temp);

		System.out.println("\nCurrent Element :" + nNode.getNodeName());

		if (nNode.getNodeType() == Node.ELEMENT_NODE) {

			Element eElement = (Element) nNode;
			

			System.out.println("InvoicesId : " + eElement.getElementsByTagName("InvoicesId").item(0).getTextContent());
			System.out.println("priceID : " + eElement.getElementsByTagName("priceID").item(0).getTextContent());
			System.out.println("locationIDFrom : " + eElement.getElementsByTagName("locationIDFrom").item(0).getTextContent());
			System.out.println("locationIDTO : " + eElement.getElementsByTagName("locationIDTO").item(0).getTextContent());
			System.out.println("locationNameFrom : " + eElement.getElementsByTagName("locationNameFrom").item(0).getTextContent());
			System.out.println("locationNameTo : " + eElement.getElementsByTagName("locationNameTo").item(0).getTextContent());
			System.out.println("price : " + eElement.getElementsByTagName("price").item(0).getTextContent());
			System.out.println("PO : " + eElement.getElementsByTagName("PO").item(0).getTextContent());
			System.out.println("OrderDate : " + eElement.getElementsByTagName("OrderDate").item(0).getTextContent());
			System.out.println("OrderID : " + eElement.getElementsByTagName("OrderID").item(0).getTextContent());
			System.out.println("customerID : " + eElement.getElementsByTagName("customerID").item(0).getTextContent());
			System.out.println("BillingAddress : " + eElement.getElementsByTagName("BillingAddress").item(0).getTextContent());
			System.out.println("ContactName : " + eElement.getElementsByTagName("ContactName").item(0).getTextContent());
			System.out.println("CellNumber : " + eElement.getElementsByTagName("CellNumber").item(0).getTextContent());
			System.out.println("transactionID : " + eElement.getElementsByTagName("transactionID").item(0).getTextContent());
			System.out.println("locationID : " + eElement.getElementsByTagName("locationID").item(0).getTextContent());
			System.out.println("locationCode : " + eElement.getElementsByTagName("locationCode").item(0).getTextContent());
			

		}
	}
    } catch (Exception e) {
	e.printStackTrace();
    }
  }

}