/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;
import parser.*;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author Suvarna
 */
public class SaxParserLocation {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
         try {

	SAXParserFactory factory = SAXParserFactory.newInstance();
	SAXParser saxParser = factory.newSAXParser();

	DefaultHandler handler;
             handler = new DefaultHandler() {
                 
                 boolean locationID = false;
                 boolean locName = false;
                 boolean locationCode = false;
                 boolean isActive = false;
                 boolean customerID = false;
                 boolean address = false;
                 boolean city = false;
                 boolean state = false;
                 boolean postalcode = false;
                 boolean locationcontactname = false;
                 boolean locphone = false;
                 boolean locemail = false;
                  
                 
                 
                 
                 @Override
                 public void startElement(String uri, String localName,String qName,
                         Attributes attributes) throws SAXException {
                     
                     System.out.println("Start Element :" + qName);
                     
                     if (qName.equalsIgnoreCase("locationID")) {
                         locationID = true;
                     }
                     
                     if (qName.equalsIgnoreCase("locName")) {
                         locName = true;
                     }
                     
                     if (qName.equalsIgnoreCase("locationCode")) {
                         locationCode = true;
                     }
                     
                     if (qName.equalsIgnoreCase("isActive")) {
                         isActive = true;
                     }
                     if (qName.equalsIgnoreCase("customerID")) {
                         customerID = true;
                     }
                     if (qName.equalsIgnoreCase("Address")) {
                         address = true;
                     }
                     if (qName.equalsIgnoreCase("City")) {
                         city = true;
                     }
                     if (qName.equalsIgnoreCase("State")) {
                         state = true;
                     }
                     if (qName.equalsIgnoreCase("City")) {
                         city = true;
                     }
                     if (qName.equalsIgnoreCase("PostalCode")) {
                         postalcode = true;
                     }
                      if (qName.equalsIgnoreCase("LocationContactName")) {
                         locationcontactname = true;
                     }
                       if (qName.equalsIgnoreCase("LocPhone")) {
                         locphone = true;
                     }
                         if (qName.equalsIgnoreCase("LocEmail")) {
                         locemail = true;
                     }
                        
                     
                     
                 }
                 
                 @Override
                 public void endElement(String uri, String localName,
                         String qName) throws SAXException {
                     
                     System.out.println("End Element :" + qName);
                     
                 }
                 
                 public void characters(char ch[], int start, int length) throws SAXException {
                 
                 if (locationID) {
                 System.out.println("locationID : " + new String(ch, start, length));
                 locationID = false;
                 }
                 
                 if (locName) {
                 System.out.println("locName : " + new String(ch, start, length));
                 locName = false;
                 }
                 
                 if (locationCode) {
                 System.out.println("locationCode : " + new String(ch, start, length));
                 locationCode = false;
                 }
                 
                 if (isActive) {
                 System.out.println("isActive : " + new String(ch, start, length));
                 isActive = false;
                 }
                 if (customerID) {
                 System.out.println("customerID : " + new String(ch, start, length));
                 customerID = false;
                 }
                 if (address) {
                 System.out.println("Address : " + new String(ch, start, length));
                 address = false;
                 }
                 if (city) {
                 System.out.println("city : " + new String(ch, start, length));
                 city = false;
                 }
                 if (state) {
                 System.out.println("state : " + new String(ch, start, length));
                 state = false;
                 }
                 if (postalcode) {
                 System.out.println("postalCode : " + new String(ch, start, length));
                 postalcode = false;
                 }
                 if (locationcontactname) {
                 System.out.println("locationContactName : " + new String(ch, start, length));
                 locationcontactname = false;
                 }
                 if (locphone) {
                 System.out.println("locPhone : " + new String(ch, start, length));
                 locphone = false;
                 }
                 if (locemail) {
                 System.out.println("locEmail : " + new String(ch, start, length));
                 locemail = false;
                 }
                
                 
                 
                 }
                 
             };
         saxParser.parse("C:\\Users\\Suvarna\\Documents\\NetBeansProjects\\SOA_Project1\\src\\XML\\Location.xml", handler);

     } catch (IOException | ParserConfigurationException | SAXException e) {
     }
    }
    
}
