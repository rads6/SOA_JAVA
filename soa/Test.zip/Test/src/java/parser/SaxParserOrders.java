package parser;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SaxParserOrders {

   public static void main(String argv[]) {

    try {

	SAXParserFactory factory = SAXParserFactory.newInstance();
	SAXParser saxParser = factory.newSAXParser();

	DefaultHandler handler = new DefaultHandler() {

	boolean OrderID = false;
	boolean OrderDate = false;
    boolean EmployeeID = false;
	boolean TruckID = false;
	boolean isSpecial = false;
    boolean PurchaseOrderNumber = false;
	boolean OrderTotalAmount = false;
	boolean VIN = false;
	boolean CustomerID = false;
	
	

	public void startElement(String uri, String localName,String qName,
                Attributes attributes) throws SAXException {

		System.out.println("Start Element :" + qName);

		if (qName.equalsIgnoreCase("OrderID")) {
			OrderID = true;
		}

		if (qName.equalsIgnoreCase("OrderDate")) {
			OrderDate = true;
		}
        if (qName.equalsIgnoreCase("CustomerID")) {
        	CustomerID = true;
        	
		}
        if (qName.equalsIgnoreCase("EmployeeID")) {
			EmployeeID = true;
		}

		if (qName.equalsIgnoreCase("TruckID")) {
			TruckID = true;
		}
		if (qName.equalsIgnoreCase("isSpecial")) {
			isSpecial = true;
		}
        if (qName.equalsIgnoreCase("PurchaseOrdernumber")) {
			PurchaseOrderNumber = true;
		}

		if (qName.equalsIgnoreCase("OrderTotalAmount")) {
			OrderTotalAmount = true;
		}
		if (qName.equalsIgnoreCase("VIN")) {
			VIN = true;
		}
		
	}

	public void endElement(String uri, String localName,
		String qName) throws SAXException {

		System.out.println("End Element :" + qName);

	}

	public void characters(char ch[], int start, int length) throws SAXException {

		if (OrderID) {
			System.out.println("OrderID : " + new String(ch, start, length));
			OrderID = false;
		}

		if (OrderDate) {
			System.out.println("OrderDate : " + new String(ch, start, length));
			OrderDate = false;
		}
		if (CustomerID) {
			System.out.println("CustomerID : " + new String(ch, start, length));
			CustomerID = false;
		}

		if (EmployeeID) {
			System.out.println("EmployeeID : " + new String(ch, start, length));
			EmployeeID = false;
		}

		if (TruckID) {
			System.out.println("TruckID : " + new String(ch, start, length));
			TruckID = false;
		}
		if (isSpecial) {
			System.out.println("isSpecial : " + new String(ch, start, length));
			isSpecial = false;
		}
        if (PurchaseOrderNumber) {
			System.out.println("PurchaseOrdernumber : " + new String(ch, start, length));
			 PurchaseOrderNumber = false;
		}
                if (OrderTotalAmount) {
			System.out.println("OrderTotalAmount : " + new String(ch, start, length));
			OrderTotalAmount = false;
		}
                if (VIN) {
			System.out.println("VIN : " + new String(ch, start, length));
			VIN = false;
		}
		
	}

     };

       saxParser.parse("C:/Users/gupta/workspace/WebService/XML/Orders.xml", handler);

     } catch (Exception e) {
       e.printStackTrace();
     }

   }

}