package parser;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SaxParserTrucks {

   public static void main(String argv[]) {

    try {

	SAXParserFactory factory = SAXParserFactory.newInstance();
	SAXParser saxParser = factory.newSAXParser();

	DefaultHandler handler = new DefaultHandler() {

	boolean truckno = false;
	boolean make = false;
	boolean year = false;
	boolean model = false;
	boolean licenseplateno = false;
	boolean employeeid = false;
	boolean color = false;
	boolean vin = false;

	public void startElement(String uri, String localName,String qName,
                Attributes attributes) throws SAXException {

		System.out.println("Start Element :" + qName);

		if (qName.equalsIgnoreCase("TruckNo")) {
			truckno = true;
		}

		if (qName.equalsIgnoreCase("Make")) {
			make = true;
		}

		if (qName.equalsIgnoreCase("Year")) {
			year = true;
		}

		if (qName.equalsIgnoreCase("Model")) {
			model = true;
		}
		if (qName.equalsIgnoreCase("LicensePlateNo")) {
			licenseplateno = true;
		}
		if (qName.equalsIgnoreCase("EmployeeID")) {
			employeeid = true;
		}
		if (qName.equalsIgnoreCase("Color")) {
			color = true;
		}
		if (qName.equalsIgnoreCase("VIN")) {
			vin = true;
		}

	}

	public void endElement(String uri, String localName,
		String qName) throws SAXException {

		System.out.println("End Element :" + qName);

	}

	public void characters(char ch[], int start, int length) throws SAXException {

		if (truckno) {
			System.out.println("TruckNo : " + new String(ch, start, length));
			truckno = false;
		}

		if (make) {
			System.out.println("Make : " + new String(ch, start, length));
			make = false;
		}

		if (year) {
			System.out.println("Year : " + new String(ch, start, length));
			year = false;
		}

		if (model) {
			System.out.println("Model : " + new String(ch, start, length));
			model = false;
		}
		if (licenseplateno) {
			System.out.println("LicensePlateNo : " + new String(ch, start, length));
			licenseplateno = false;
		}
		if (employeeid) {
			System.out.println("EmployeeID : " + new String(ch, start, length));
			employeeid = false;
		}
		if (color) {
			System.out.println("Color : " + new String(ch, start, length));
			color = false;
		}
		if (vin) {
			System.out.println("VIN : " + new String(ch, start, length));
			vin = false;
		}


	}

     };

       saxParser.parse("E:\\Study\\Sem1\\510_JP\\Workspace\\WebService\\src\\parser\\Trucks.xml", handler);

     } catch (Exception e) {
       e.printStackTrace();
     }

   }

}