package parser;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SaxParserTransaction {

   public static void main(String argv[]) {

    try {

	SAXParserFactory factory = SAXParserFactory.newInstance();
	SAXParser saxParser = factory.newSAXParser();

	DefaultHandler handler = new DefaultHandler() {

        boolean transactionID = false;
	boolean OrderID = false;
	boolean priceID = false;
	boolean transactionDate = false;
	boolean transactionDescription = false;
	boolean transactionAmount = false;
	boolean employeeID= false;
	boolean truckNo = false;
	boolean discount = false;
        
	
	

	public void startElement(String uri, String localName,String qName,
                Attributes attributes) throws SAXException {

		System.out.println("Start Element :" + qName);

		if (qName.equalsIgnoreCase("transactionID")) {
			transactionID = true;
		}

		if (qName.equalsIgnoreCase("OrderID")) {
			OrderID = true;
		}

		if (qName.equalsIgnoreCase("priceID")) {
			priceID = true;
		}

		if (qName.equalsIgnoreCase("transactionDate")) {
			transactionDate = true;
		}
		if (qName.equalsIgnoreCase("transactionDescription")) {
			transactionDescription = true;
		}
       if (qName.equalsIgnoreCase("transactionAmount")) {
			transactionAmount = true;
		}

		if (qName.equalsIgnoreCase("employeeID")) {
			employeeID = true;
		}

		if (qName.equalsIgnoreCase("truckNo")) {
			truckNo = true;
		}
		if (qName.equalsIgnoreCase("discount")) {
			discount = true;
		} 
               
		
		
	}

	public void endElement(String uri, String localName,
		String qName) throws SAXException {

		System.out.println("End Element :" + qName);

	}

	public void characters(char ch[], int start, int length) throws SAXException {

		if (transactionID) {
			System.out.println("transactionID : " + new String(ch, start, length));
			transactionID = false;
		}

		if (OrderID) {
			System.out.println("OrderID : " + new String(ch, start, length));
			OrderID = false;
		}

		if (priceID) {
			System.out.println("priceID : " + new String(ch, start, length));
			priceID = false;
		}

		if (transactionDate) {
			System.out.println("transactionDate : " + new String(ch, start, length));
			transactionDate = false;
		}
		if (transactionDescription) {
			System.out.println("transactionDescription : " + new String(ch, start, length));
			transactionDescription = false;
		}
               if (transactionAmount) {
			System.out.println("transactionAmount : " + new String(ch, start, length));
			transactionAmount = false;
		}

		if (employeeID) {
			System.out.println("employeeID : " + new String(ch, start, length));
			employeeID = false;
		}

		if (truckNo) {
			System.out.println("truckNo : " + new String(ch, start, length));
			truckNo = false;
		}
		if (discount) {
			System.out.println("discount : " + new String(ch, start, length));
			discount = false;
		}
                
		
	}

     };

       saxParser.parse("C:/Users/gupta/workspace/WebService/XML/transaction.xml", handler);

     } catch (Exception e) {
       e.printStackTrace();
     }

   }

}