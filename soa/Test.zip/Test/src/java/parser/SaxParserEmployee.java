package parser;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class SaxParserEmployee {

   public static void main(String argv[]) {

    try {

	SAXParserFactory factory = SAXParserFactory.newInstance();
	SAXParser saxParser = factory.newSAXParser();

	DefaultHandler handler = new DefaultHandler() {

	boolean EmployeeID = false;
	boolean FirstName = false;
	boolean LastName = false;
	boolean Email = false;
	boolean Extension = false;
	boolean HomePhone = false;
	boolean CellPhone = false;
	boolean jobTitle = false;
	boolean SocialSecurityNumber = false;
	boolean DriverLicenseNumber = false;
	boolean City = false;
	boolean State = false;
	boolean PostalCode = false;
	
	public void startElement(String uri, String localName,String qName,
                Attributes attributes) throws SAXException {

		System.out.println("Start Element :" + qName);

		if (qName.equalsIgnoreCase("EmployeeID")) {
			EmployeeID = true;
		}

		if (qName.equalsIgnoreCase("FirstName")) {
			FirstName = true;
		}

		if (qName.equalsIgnoreCase("LastName")) {
			LastName = true;
		}

		if (qName.equalsIgnoreCase("Email")) {
			Email = true;
		}
		if (qName.equalsIgnoreCase("Extension")) {
			Extension = true;
		}
		if (qName.equalsIgnoreCase("HomePhone")) {
			HomePhone = true;
		}
		if (qName.equalsIgnoreCase("CellPhone")) {
			CellPhone = true;
		}
		if (qName.equalsIgnoreCase("jobTitle")) {
			jobTitle = true;
		}
		if (qName.equalsIgnoreCase("SocialSecurityNumber")) {
			SocialSecurityNumber = true;
		}
		if (qName.equalsIgnoreCase("DriverLicenseNumber")) {
			DriverLicenseNumber = true;
		}
		if (qName.equalsIgnoreCase("City")) {
			City = true;
		}
		if (qName.equalsIgnoreCase("State")) {
			State = true;
		}
		if (qName.equalsIgnoreCase("PostalCode")) {
			PostalCode = true;
		}
		
	}

	public void endElement(String uri, String localName,
		String qName) throws SAXException {

		System.out.println("End Element :" + qName);

	}

	public void characters(char ch[], int start, int length) throws SAXException {

		if (EmployeeID) {
			System.out.println("EmployeeID  : " + new String(ch, start, length));
			EmployeeID = false;
		}

		if (FirstName) {
			System.out.println("FirstName  : " + new String(ch, start, length));
			FirstName = false;
		}

		if (LastName) {
			System.out.println("LastName : " + new String(ch, start, length));
			LastName = false;
		}

		if (Email) {
			System.out.println("Email : " + new String(ch, start, length));
			Email = false;
		}
		if (Extension) {
			System.out.println("Extension : " + new String(ch, start, length));
			Extension = false;
		}
		if (HomePhone) {
			System.out.println("HomePhone : " + new String(ch, start, length));
			HomePhone = false;
		}
		if (CellPhone) {
			System.out.println("CellPhone : " + new String(ch, start, length));
			CellPhone = false;
		}
		if (jobTitle) {
			System.out.println("jobTitle : " + new String(ch, start, length));
			jobTitle = false;
		}
		if (SocialSecurityNumber) {
			System.out.println("SocialSecurityNumber : " + new String(ch, start, length));
			SocialSecurityNumber = false;
		}
		if (DriverLicenseNumber) {
			System.out.println("DriverLicenseNumber : " + new String(ch, start, length));
			DriverLicenseNumber = false;
		}
		if (City) {
			System.out.println("City : " + new String(ch, start, length));
			City = false;
		}
		if (State) {
			System.out.println("State : " + new String(ch, start, length));
			State = false;
		}
		if (PostalCode) {
			System.out.println("PostalCode : " + new String(ch, start, length));
			PostalCode = false;
		}

	}

     };

       saxParser.parse("E:\\Study\\Sem1\\510_JP\\Workspace\\WebService\\src\\parser\\Invoice.xml", handler);

     } catch (Exception e) {
       e.printStackTrace();
     }

   }

}