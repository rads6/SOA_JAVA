package parser;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

//import Trucking_Java_Object.comments;

import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;

public class DomParserPayments {

  public static void main(String argv[]) {
	  
	//comments comments = new comments();
    try {

	File fXmlFile = new File("C:/Users/gupta/workspace/WebService/XML/payments.xml");
	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	Document doc = dBuilder.parse(fXmlFile);

	
	doc.getDocumentElement().normalize();

	System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

	NodeList nList = doc.getElementsByTagName("record");

	System.out.println("----------------------------");

	for (int temp = 0; temp < nList.getLength(); temp++) {

		Node nNode = nList.item(temp);

		System.out.println("\nCurrent Element :" + nNode.getNodeName());

		if (nNode.getNodeType() == Node.ELEMENT_NODE) {

			Element eElement = (Element) nNode;
			

			System.out.println("PaymentID : " + eElement.getElementsByTagName("PaymentID").item(0).getTextContent());
			System.out.println("OrderID : " + eElement.getElementsByTagName("OrderID").item(0).getTextContent());
			System.out.println("PaymentMethodID : " + eElement.getElementsByTagName("PaymentMethodID").item(0).getTextContent());
			System.out.println("PaymentAmount : " + eElement.getElementsByTagName("PaymentAmount").item(0).getTextContent());
			System.out.println("PaymentDate : " + eElement.getElementsByTagName("PaymentDate").item(0).getTextContent());
			System.out.println("CheckNumber : " + eElement.getElementsByTagName("CheckNumber").item(0).getTextContent());
			System.out.println("CreditCard : " + eElement.getElementsByTagName("CreditCard").item(0).getTextContent());
			System.out.println("CreditCardNumber : " + eElement.getElementsByTagName("CreditCardNumber").item(0).getTextContent());
			System.out.println("CardholdersName : " + eElement.getElementsByTagName("CardholdersName").item(0).getTextContent());
			System.out.println("CreditCardExpDate : " + eElement.getElementsByTagName("CreditCardExpDate").item(0).getTextContent());
			System.out.println("CreditCardAuthorizationNumber : " + eElement.getElementsByTagName("CreditCardAuthorizationNumber").item(0).getTextContent());
			
			
		}
	}
    } catch (Exception e) {
	e.printStackTrace();
    }
  }

}