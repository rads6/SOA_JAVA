/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;
import parser.*;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 *
 * @author Suvarna
 */
public class SaxParserPricing {

    /**
     * @param args the command line arguments
     */
    
    public static void main(String[] args) {
        // TODO code application logic here
        try {

	SAXParserFactory factory = SAXParserFactory.newInstance();
	SAXParser saxParser = factory.newSAXParser();

        
        DefaultHandler handler = new DefaultHandler() {


	boolean priceID = false;
	boolean locationIDFrom = false;
	boolean locationIDTO = false;
	boolean price = false;
	boolean locationNameFrom = false;
	boolean locationNameTo = false;
	boolean customerID = false;
	
        
        

	public void startElement(String uri, String localName,String qName,
                Attributes attributes) throws SAXException {

		System.out.println("Start Element :" + qName);

		if (qName.equalsIgnoreCase("priceID")) {
			priceID = true;
		}

		if (qName.equalsIgnoreCase("locationIDFrom")) {
			locationIDFrom = true;
		}

		if (qName.equalsIgnoreCase("locationIDTO")) {
			locationIDTO = true;
		}

		if (qName.equalsIgnoreCase("price")) {
			price = true;
		}
		if (qName.equalsIgnoreCase("locationNameFrom")) {
			locationNameFrom = true;
		}
		if (qName.equalsIgnoreCase("locationNameTo")) {
			locationNameTo = true;
		}
		if (qName.equalsIgnoreCase("customerID")) {
			customerID = true;
		}
		

	}

        
	public void endElement(String uri, String localName,
		String qName) throws SAXException {

		System.out.println("End Element :" + qName);

	}
        
        
         public void characters(char ch[], int start, int length) throws SAXException {
                 
                 if (priceID) {
                 System.out.println("priceID : " + new String(ch, start, length));
                 priceID = false;
                 }
                 
                 if (locationIDFrom) {
                 System.out.println("locationIDFrom : " + new String(ch, start, length));
                 locationIDFrom = false;
                 }
                 
                 if (locationIDTO) {
                 System.out.println("locationIDTO : " + new String(ch, start, length));
                 locationIDTO = false;
                 }
                 
                 if (price) {
                 System.out.println("price : " + new String(ch, start, length));
                 price = false;
                 }
                 if (locationNameFrom) {
                 System.out.println("locationNameFrom : " + new String(ch, start, length));
                 locationNameFrom = false;
                 }
                 if (locationNameTo) {
                 System.out.println("locationNameTo : " + new String(ch, start, length));
                 locationNameTo = false;
                 }
                 if (customerID) {
                 System.out.println("customerID : " + new String(ch, start, length));
                 customerID = false;
                 }
                 
         }
                 
                 
         
         };

       saxParser.parse("..\\SOA_Project1\\src\\XML\\Pricing.xml", handler);

     } catch (IOException | ParserConfigurationException | SAXException e) {
         
         System.out.println("Exception Found!!");
     }

   }
}

        
                
    

    
    

