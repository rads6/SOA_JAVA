/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package parser;
import parser.*;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.Document;
import org.w3c.dom.NodeList;

import model.*;

import org.w3c.dom.Node;
import org.w3c.dom.Element;
import java.io.File;
import java.io.IOException;
import javax.xml.parsers.ParserConfigurationException;
import org.w3c.dom.DOMException;
import org.xml.sax.SAXException;

/**
 *
 * @author Suvarna
 */
public class DomParserPricing {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Pricing p = new Pricing();
         try {

	File fXmlFile = new File("..\\SOA_Project1\\src\\XML\\Pricing.xml");
	DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
	Document doc = dBuilder.parse(fXmlFile);
	doc.getDocumentElement().normalize();

	System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

	NodeList nList = doc.getElementsByTagName("record");

	/*System.out.println("----------------------------");*/

	for (int temp = 0; temp < nList.getLength(); temp++) {

		Node nNode = nList.item(temp);

		System.out.println("\nCurrent Element :" + nNode.getNodeName());

		if (nNode.getNodeType() == Node.ELEMENT_NODE) {

			Element eElement = (Element) nNode;
                        
//			p.setPriceID(Integer.parseInt(eElement.getElementsByTagName("priceID").item(0).getTextContent()));
//			p.setLocationIDFrom(eElement.getElementsByTagName("locationIDFrom").item(0).getTextContent());
//                        p.setLocationIDTO(eElement.getElementsByTagName("locationIDTO").item(0).getTextContent());
//                        p.setPrice(Integer.parseInt(eElement.getElementsByTagName("price").item(0).getTextContent()));
//                        p.setLocationNameFrom(eElement.getElementsByTagName("locationNameFrom").item(0).getTextContent());
//                        p.setLocationNameTo(eElement.getElementsByTagName("locationNameTo").item(0).getTextContent());
//                        p.setCustomerID(Integer.parseInt(eElement.getElementsByTagName("customerID").item(0).getTextContent()));
//                       
                        
			System.out.println("priceID : " + eElement.getElementsByTagName("priceID").item(0).getTextContent());
			System.out.println("locationIDFrom : " + eElement.getElementsByTagName("locationIDFrom").item(0).getTextContent());
			System.out.println("locationIDTO : " + eElement.getElementsByTagName("locationIDTO").item(0).getTextContent());
			System.out.println("price : " + eElement.getElementsByTagName("price").item(0).getTextContent());
			System.out.println("locationNameFrom : " + eElement.getElementsByTagName("locationNameFrom").item(0).getTextContent());
                        System.out.println("locationNameTo : " + eElement.getElementsByTagName("locationNameTo").item(0).getTextContent());
                        System.out.println("customerID : " + eElement.getElementsByTagName("customerID").item(0).getTextContent());
                        

		}
	}
    } catch (IOException | NumberFormatException | ParserConfigurationException | DOMException | SAXException e) {
    }
  }

        
    }
    

