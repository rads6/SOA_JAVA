@javax.xml.bind.annotation.XmlSchema(namespace = "http://customer/")
package customer;
